(defproject set_theory "1.0.0-SNAPSHOT"
  :description "Clojure illustration of set theory."
  :url "http://kisom.github.com/blog/2012/01/23/basic-set-theory/"
  :author "Kyle Isom <coder@kyleisom.net>"
  :main set_theory.core
  :dependencies [[org.clojure/clojure "1.3.0"]])