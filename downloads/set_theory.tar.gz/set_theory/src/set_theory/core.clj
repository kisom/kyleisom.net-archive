(ns set_theory.core
  (:require [clojure.set]))

;; define the sets
; the superset
(def library #{ "Natural Language Processing with Python",
                "Learning OpenCV",
                "Code Complete", 
                "Mastering Algorithms with C", 
                "The Joy of Clojure", 
                "Mining the Social Web", 
                "Algorithms In A Nutshell",
                "Introduction to Information Retrieval" 
                "Network Security With OpenSSL", 
                "RADIUS" })
(def library #^{ :doc "the example superset" } library)

;; the subsets
(def mobi
  #^{ :doc "the subset of books in mobi format" }
  #{"Natural Language Processing with Python", "Code Complete",
    "Introduction to Information Retrieval"})
(def epub
  #^{ :doc "the subset of books in epub format" }
  #{"The Joy of Clojure", "Mining the Social Web", "Code Complete"})

(def mobile
  #^{ :doc "the subset of all ebooks in a mobile format (union example)" }
  (clojure.set/union mobi epub))

(def both_formats
  #^{ :doc "the subset of ebooks in both mobile formats (intersection example)" }
  (clojure.set/intersection mobi epub))

(def only_mobi
  #^{ :doc "the subset of books only in mobi format (difference example)" }
  (clojure.set/difference mobi epub))

(def only_epub
  #^{ :doc "the subset of books only in epub format (difference example)" }
  (clojure.set/difference epub mobi))

(def not_mobi
  #^{ :doc "the subset of books not in mobi format (complement example)" }
  (clojure.set/difference library mobi))

(defn -main []
  "Display the resulting sets."
  
  ;; union illustration
  (println "union illustration (books in either mobile format)")
  (doseq [book mobile] 
    (println "\t" book))

  ;; intersection illustration
  (println "intersection illustration (books in both mobile formats)")
  (doseq [book both_formats] 
    (println "\t" book))

  ;; difference examples
  (println "difference illustrations")
  (println "books only in mobi format:")
  (doseq [book only_mobi]
    (println "\t" book))

  (println "books only in epub format:")
  (doseq [book only_epub]
    (println "\t" book))

  ;; complement illustration
  (println "complement illustration")
  (println "books not in mobi format, using the library superset:")
  (doseq [book not_mobi]
    (println "\t" book)))