;;;; tests for the Clojure illustrations of basic set theory
;;;; these are somewhat contrived, but added for completeness

(ns set_theory.test.core
  (:use [set_theory.core])
  (:use [clojure.test]))

;; sanity check
(def expected-library
  #^{ :doc "what library should be" }
  #{ "Mining the Social Web"
     "Algorithms In A Nutshell"
     "Introduction to Information Retrieval"
     "Mastering Algorithms with C"
     "Code Complete"
     "RADIUS"
     "The Joy of Clojure"
     "Network Security With OpenSSL"
     "Natural Language Processing with Python"
     "Learning OpenCV"})

(deftest check-superset
  "Sanity check."
  (is (= library expected-library)))

(deftest union
  "Validate the union illustration."
  (is (= mobile
         #{"Introduction to Information Retrieval"
           "Code Complete"
           "Natural Language Processing with Python"
           "The Joy of Clojure"
           "Mining the Social Web"})))

(deftest intersection
  "Validate the intersection illustration."
  (is (= both-formats #{ "Code Complete" })))

(deftest difference
  "Validate the difference illustrations."
  (is (= only-mobi #{ "Natural Language Processing with Python"
                      "Introduction to Information Retrieval"}))
  (is (= only-epub #{ "The Joy of Clojure" "Mining the Social Web" })))

(deftest complement
  "Validate the complement example."
  (is (= not-mobi
         #{ "Algorithms In A Nutshell"
            "Mastering Algorithms with C"
            "RADIUS"
            "The Joy of Clojure"
            "Network Security With OpenSSL"
            "Learning OpenCV"
            "Mining the Social Web" })))
