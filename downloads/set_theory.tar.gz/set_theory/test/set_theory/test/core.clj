(ns set_theory.test.core
  (:use [set_theory.core])
  (:use [clojure.test]))

(deftest replace-me ;; FIXME: write
  (is false "No tests have been written."))
